#include <iostream>

/* Parametre olarak g�nderilen tam say�n�n Tek veya �ift olma durumu kontrol edip �ift ise geriye true de�eri d�nen fonksiyon yaz�n�z ve kullan�n�z. */
using namespace std;

bool CiftMi(int sayi)
{
	bool sonuc= true;
	for(int i=1; i<=sayi;i++)
	{
		if(sayi % 2 ==0)
		{
			sonuc = true;
			break;
		}
	}
	return sonuc;
}
int main(int argc, char** argv)
{
	int sayi;
	cout<<"Bir sayi giriniz=";
	cin>>sayi;
	if(CiftMi(sayi))
	{
		cout<<"girilen sayi ciftdir.";
	}
	else{
		cout<<"girilen sayi tektir";
	}
	
	system("Pause");
	return 0;
}
