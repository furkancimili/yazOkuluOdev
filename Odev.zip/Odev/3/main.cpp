#include <iostream>

/* Parametre olarak g�nderilen bir x say�s� i�in F(x) = ((x*x)+3)/2  i�lemini yap�n�z ve sonuc geriye d�necek */
using namespace std;

double Fx(int x)
{
	double sonuc = (x*x+3)/2;
	return sonuc;
}

int main(int argc, char** argv) {

	int sayi;
	cout<<"bir sayi giriniz:";
	cin>>sayi;
	cout<<"Fx(sayi)"<<Fx(sayi)<<endl;
	
	system("Pause");	
	return 0;
}

