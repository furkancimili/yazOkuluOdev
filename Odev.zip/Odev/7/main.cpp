#include <iostream>

/*Kullan�c�n girece�i n say�s�na g�re n!`i hesaplay�p ekranda g�steren program� yaz�n�z(n! Hesab� recursive fonksiyonda yap�lacakt�r) */

using namespace std;

	int Fakt(int N)
	{
		if(N > 0)
		return N*Fakt(N-1);
		return 1;
	}

int main(int argc, char** argv) 
{
	int N;
	cout<<"Bir sayi giriniz:";
	cin>>N;

    cout<<N<<"!= "<<Fakt (N);
	
	return 0;
}
