#include <iostream>

using namespace std;

int main(int argc, char** argv) 
{
	int iskod, sayi1, sayi2, sonuc;
	
	do{
		cout<<"1. sayiyi giriniz : ";
		cin>>sayi1;
		cout<<"2. sayiyi giriniz : ";
		cin>>sayi2;
		
		cout<<"Islem Tablosu"<<endl<<
			"Toplama icin....[1]"<<endl<<
			"Cikarma icin....[2]"<<endl<<
			"Bolme icin......[3]"<<endl<<
			"Carpma icin.....[4]"<<endl<<
			"Cikis icin......[5]"<<endl<<endl<<
			"Islem Kodu Giriniz : ";
		
		cin>>iskod;
	
	
	
		switch(iskod)
		{
			case 1:
				sonuc = sayi1 + sayi2;
				break;
			case 2:
				sonuc = sayi1 - sayi2;
				break;
			case 3:
				sonuc = sayi1 / sayi2;
				break;
			case 4:
				sonuc = sayi1 * sayi2;
				break;
			default:
				cout<<"Yanlis Islem Kodu Girdiniz!!!"<<endl;
				break;
		}
		cout<<"Sonuc = "<<sonuc<<endl<<endl;
		sonuc = 0;
	
	}
	while(iskod != 5);
	
	system("pause");	
	return 0;
}


