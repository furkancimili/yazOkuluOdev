#include <iostream>

using namespace std;

int main(int argc, char** argv) 
{
	
	int iskod;
	
	do{
	cout<<"Islem Tablosu"<<endl<<
		"Kirmizi icin...[1]"<<endl<<
		"Beyaz icin.....[2]"<<endl<<
		"Yesil icin.....[3]"<<endl<<
		"Cikis icin.....[4]"<<endl<<endl<<
		"Renk Seciniz : ";
		
	cin>>iskod;
	

		switch(iskod)
		{
			case 1:
				cout<<"Kirmizi secildi..."<<endl;
				break;
			case 2:
				cout<<"Beyaz secildi..."<<endl;
				break;
			case 3:
				cout<<"Yesil secildi..."<<endl;
				break;
			default:
				cout<<"Yanlis Secim Yapildi!!!"<<endl;	
				break;
		}
	}while(iskod != 4);
	
	system("Pause");
	return 0;
}
	
	
	
 


